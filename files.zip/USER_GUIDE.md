# Smart Study Planner - Quick Start Guide

## Getting Started

### Prerequisites
- Python 3.x installed on your computer
- Text editor or IDE (optional, for viewing the code)

### Running the Program

1. **Open Terminal/Command Prompt** in the directory containing `smart_study_planner.py`
2. **Run the program:**
   ```bash
   python smart_study_planner.py
   ```
   or
   ```bash
   python3 smart_study_planner.py
   ```
3. **See the welcome message** and main menu

---

## Menu Options Explained

### Option 1: Add a Study Session 📝
**What it does:** Log a new study session with details about what you studied.

**What you'll be asked:**
1. **Subject name** - The subject you studied (e.g., "Mathematics", "English")
2. **Topic covered** - Specific topic (e.g., "Quadratic Equations", "Shakespeare's Romeo and Juliet")
3. **Date or day label** - When you studied (e.g., "Monday", "2024-01-15")
4. **Duration in minutes** - How long you studied (must be a positive whole number)

**Example:**
```
Subject name: Mathematics
Topic covered: Quadratic Equations
Date or day label: Monday
Duration in minutes: 45
✓ Session added! (Medium session - 45 minutes)
```

**Duration Classification:**
- **Short:** Less than 30 minutes
- **Medium:** 30 to 90 minutes
- **Long:** More than 90 minutes

---

### Option 2: View All Sessions 👀
**What it does:** Shows all your logged study sessions in a neat table.

**Display includes:**
- Subject name
- Topic covered
- Date/day label
- Duration (minutes)
- Classification (Short/Medium/Long)

**Example Output:**
```
Subject        Topic                    Date            Duration (min)  Classification
Mathematics    Quadratic Equations      Monday          45              Medium
English        Shakespeare              Tuesday         90              Medium
History        American Revolution      Wednesday       120             Long
Chemistry      Periodic Table           Thursday        20              Short
```

**What if there are no sessions?**
```
⊘ No study sessions recorded yet. Start by adding a session!
```

---

### Option 3: Search Sessions by Subject 🔍
**What it does:** Find all sessions for a specific subject and see total time spent.

**What you'll be asked:**
- **Subject name:** Type the subject you want to search for (search is case-insensitive)

**Example:**
```
Enter subject name to search: Mathematics

SESSIONS FOR: MATHEMATICS
==============================
Topic                          Date            Duration (min)  Classification
Quadratic Equations            Monday          45              Medium
Linear Functions               Tuesday         30              Medium
Calculus Intro                 Wednesday       100             Long
==============================
Total time on Mathematics: 4.42 hours (265 minutes)
```

**What if the subject isn't found?**
```
⊘ No sessions found for subject: 'Physics'
```

---

### Option 4: View Statistics 📊
**What it does:** See comprehensive analysis of your study habits.

**Statistics provided:**

#### 1. **Total Hours Studied Overall**
```
Total hours studied overall: 15.50 hours (930 minutes)
```

#### 2. **Hours Per Subject**
```
Hours per subject:
  • Chemistry: 8.33 hours
  • English: 4.00 hours
  • History: 2.50 hours
  • Mathematics: 0.67 hours
```

#### 3. **Weakest Area**
Shows which subject has the least study time (needs more attention).
```
Weakest area (least study time): Mathematics (0.67 hours)
```

#### 4. **Longest Session**
Details about your single longest study session.
```
Longest session: 150 minutes
  • Subject: Chemistry
  • Topic: Organic Chemistry - Benzene Rings
  • Date: Friday
  • Classification: Long
```

---

### Option 5: Save and Exit 💾
**What it does:** Safely save all your sessions and close the program.

**What happens:**
1. All your sessions are saved to `study_log.txt`
2. Next time you run the program, all sessions are automatically loaded
3. Program closes gracefully

```
Saving your data before exit...
✓ Saved 15 session(s) to study_log.txt
Thank you for using Smart Study Planner! 📚
```

---

## Important Notes

### Data Storage
- **File name:** `study_log.txt` (created automatically)
- **Location:** Same folder as `smart_study_planner.py`
- **Format:** JSON (human-readable)
- **Automatic:** Data saves when you exit (Option 5)

### First Run
On your first run, the program will:
- Find no existing data file
- Start with an empty sessions list
- Prompt you to add your first session

### Subsequent Runs
When you restart the program:
- It automatically loads all previous sessions
- You'll see a message: "✓ Loaded X previous session(s)"
- You can immediately continue adding, viewing, or searching

### Data Persistence Example
**Session 1 (Day 1):**
```
Run program → Add 3 sessions → Exit (saves)
```

**Session 2 (Day 2):**
```
Run program → Automatically loads 3 previous sessions
           → Add 2 more sessions → Exit (now saves 5 total)
```

---

## Tips & Best Practices

### 1. **Be Consistent with Subject Names**
Use the same spelling and capitalization for the same subject:
- ✓ Good: "Mathematics", "Mathematics", "Mathematics"
- ✗ Bad: "Mathematics", "math", "MATH" (creates 3 separate subjects)

### 2. **Use Clear Topic Names**
- ✓ "Quadratic Equations"
- ✗ "Stuff"

### 3. **Include Both Study Sessions and Breaks**
- Log each focused study session separately
- Log breaks as separate sessions if helpful
- This gives an accurate picture of your habits

### 4. **Review Statistics Regularly**
- Weekly review helps identify weak areas
- Motivates you when you see total hours increasing
- Helps balance study across subjects

### 5. **Use Case-Insensitive Search**
```
Search "mathematics" or "MATHEMATICS" or "Mathematics" → all work!
```

---

## Troubleshooting

### Q: I ran the program but nothing happened
**A:** Make sure you're in the correct directory. Use:
```bash
cd /path/to/your/files
python smart_study_planner.py
```

### Q: I get "FileNotFoundError" or "ModuleNotFoundError"
**A:** 
- Ensure Python 3.x is installed
- Ensure you're in the directory with `smart_study_planner.py`
- Try `python3` instead of `python`

### Q: Where did my data go?
**A:** Your data is in `study_log.txt`. Check that this file exists in the same folder as the program. If it's missing, run the program again—it will ask you to add sessions.

### Q: Can I edit `study_log.txt` directly?
**A:** You can view it (it's a text file), but editing manually may cause errors. It's safest to use the program to add/remove sessions.

### Q: I entered an invalid duration, now what?
**A:** The program will ask you again: "Duration must be a positive number. Please try again."

### Q: How do I delete a session?
**A:** Currently, the program doesn't have a delete feature. You can:
- Edit `study_log.txt` manually (advanced), or
- Delete the file and start fresh (all data lost)

**Future versions** will include session deletion.

---

## Example Workflow

Here's a realistic example of how to use the program:

```
Welcome to Smart Study Planner!

SMART STUDY PLANNER - MAIN MENU
1. Add a study session
2. View all sessions
3. Search sessions by subject
4. View statistics
5. Save and exit

Enter your choice (1-5): 1

ADD NEW STUDY SESSION
Subject name: Mathematics
Topic covered: Solving Quadratic Equations
Date or day label: Monday, January 15
Duration in minutes: 45
✓ Session added! (Medium session - 45 minutes)

Enter your choice (1-5): 1

ADD NEW STUDY SESSION
Subject name: English
Topic covered: Poetry Analysis
Date or day label: Tuesday, January 16
Duration in minutes: 90
✓ Session added! (Medium session - 90 minutes)

Enter your choice (1-5): 2

ALL STUDY SESSIONS
Subject        Topic                    Date                Duration (min)  Classification
Mathematics    Solving Quadratic...     Monday, January 15  45              Medium
English        Poetry Analysis          Tuesday, January 16 90              Medium

Enter your choice (1-5): 4

STUDY STATISTICS
Total hours studied overall: 2.25 hours (135 minutes)

Hours per subject:
  • English: 1.50 hours (90 minutes)
  • Mathematics: 0.75 hours (45 minutes)

Weakest area (least study time): Mathematics (0.75 hours)

Longest session: 90 minutes
  • Subject: English
  • Topic: Poetry Analysis
  • Date: Tuesday, January 16
  • Classification: Medium

Enter your choice (1-5): 5

Saving your data before exit...
✓ Saved 2 session(s) to study_log.txt
Thank you for using Smart Study Planner! 📚
```

---

## Keyboard Shortcuts

| Action | How |
|--------|-----|
| Navigate menu | Type 1-5 and press Enter |
| Fix typo before entering | Use Backspace |
| Cancel/Restart | Close program (Ctrl+C) and rerun |

---

## Contact & Support

If you find bugs or want to suggest features:
- Check your data file (`study_log.txt`) still exists
- Ensure you're using Python 3.x
- Re-run the program to see if the issue persists

---

## Version Information

- **Program Name:** Smart Study Planner v1.0
- **Language:** Python 3.x
- **Last Updated:** 2024
- **Status:** Fully functional, production-ready

Happy studying! 📚
